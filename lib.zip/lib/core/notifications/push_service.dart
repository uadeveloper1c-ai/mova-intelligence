import 'package:firebase_messaging/firebase_messaging.dart';
import '../../api/api_client.dart';

class PushService {
  final FirebaseMessaging _fm = FirebaseMessaging.instance;
  final ApiClient _apiClient;

  PushService(this._apiClient);

  Future<void> init() async {
    await _fm.requestPermission();

    final token = await _fm.getToken();
    if (token != null) {
      await _apiClient.registerDeviceToken(token);
    }

    FirebaseMessaging.onMessage.listen(_handleForeground);
  }

  void _handleForeground(RemoteMessage message) {
    // тут можно показать snackbar / диалог / локальное уведомление
    // в зависимости от message.data['type']
  }
}
