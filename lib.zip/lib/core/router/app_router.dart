// lib/core/router/app_router.dart

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../api/auth_provider.dart';
import '../../features/auth/login_page.dart';
import '../ui/app_scaffold.dart';

// сторінки вкладок
import '../../features/home/presentation/home_page.dart';
import '../../features/invoices/presentation/pages/invoices_page.dart';
import '../../features/approvals/presentation/approvals_page.dart';
import '../../features/tasks/presentation/tasks_page.dart';
import '../../features/reports/presentation/reports_page.dart';

class AppRouter {
  static GoRouter createRouter(AuthProvider auth) {
    return GoRouter(
      // перший екран — логін
      initialLocation: '/login',

      // слухаємо зміни стану авторизації
      refreshListenable: auth,

      // глобальний редірект залежно від того, залогінений користувач чи ні
      redirect: (context, state) {
        final loggedIn = auth.isLoggedIn;
        final loggingIn = state.matchedLocation == '/login';

        // якщо НЕ залогінений — відправляємо на /login
        if (!loggedIn && !loggingIn) {
          return '/login';
        }

        // якщо вже залогінений — не пускаємо назад на /login
        if (loggedIn && loggingIn) {
          return '/home';
        }

        // інакше нічого не змінюємо
        return null;
      },

      // усі маршрути застосунку
      routes: [
        // екран входу
        GoRoute(
          path: '/login',
          builder: (context, state) => const LoginPage(),
        ),

        // головна (дашборд)
        GoRoute(
          path: '/home',
          builder: (context, state) =>
          const AppScaffold(child: HomePage()),
        ),

        // рахунки / інвойси
        GoRoute(
          path: '/invoices',
          builder: (context, state) =>
          const AppScaffold(child: InvoicesPage()),
        ),

        // заявки на оплату (погодження)
        GoRoute(
          path: '/approvals',
          builder: (context, state) =>
          const AppScaffold(child: ApprovalsPage()),
        ),

        // задачі
        GoRoute(
          path: '/tasks',
          builder: (context, state) =>
          const AppScaffold(child: TasksPage()),
        ),

        // звіти
        GoRoute(
          path: '/reports',
          builder: (context, state) =>
          const AppScaffold(child: ReportsPage()),
        ),
      ],
    );
  }
}
