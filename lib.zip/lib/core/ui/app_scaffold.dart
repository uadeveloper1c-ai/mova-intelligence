import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class AppScaffold extends StatelessWidget {
  const AppScaffold({super.key, required this.child});
  final Widget child;

  static const _tabs = [
    ('/home', Icons.dashboard_outlined, 'Головна'),
    ('/invoices', Icons.receipt_long_outlined, 'Рахунки'),
    ('/approvals', Icons.verified_outlined, 'Погодження'),
    ('/tasks', Icons.checklist_outlined, 'Задачі'),
    ('/reports', Icons.bar_chart_outlined, 'Звіти'),
  ];

  @override
  Widget build(BuildContext context) {
    final loc = GoRouterState.of(context).uri.toString();
    final idx = _tabs.indexWhere((t) => loc.startsWith(t.$1));
    final selected = idx < 0 ? 0 : idx;

    return Scaffold(
      body: child,
      bottomNavigationBar: NavigationBar(
        selectedIndex: selected,
        onDestinationSelected: (i) => context.go(_tabs[i].$1),
        destinations: [
          for (final t in _tabs)
            NavigationDestination(icon: Icon(t.$2), label: t.$3),
        ],
      ),
    );
  }
}

