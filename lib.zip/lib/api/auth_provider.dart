import 'package:flutter/foundation.dart';
import 'api_client.dart';
import 'user_model.dart';

class AuthProvider extends ChangeNotifier {
  UserModel? currentUser;
  bool isLoading = false;

  bool get isLoggedIn => currentUser != null;

  Future<void> loadUser() async {
    isLoading = true;
    notifyListeners();

    try {
      final me = await ApiClient().getMe();
      if (me != null && me["success"] == true) {
        currentUser = UserModel.fromJson(me);
      } else {
        currentUser = null;
      }
    } catch (e) {
      // ВАЖНО: гасим ошибку, просто считаем, что пользователь не залогинен
      print('loadUser error: $e');
      currentUser = null;
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> login(String login, String password) async {
    isLoading = true;
    notifyListeners();

    final ok = await ApiClient().login(login, password);

    if (!ok) {
      isLoading = false;
      notifyListeners();
      return false;
    }

    await loadUser();
    return true;
  }

  Future<void> logout() async {
    currentUser = null;
    notifyListeners();
  }
}
