// lib/api/api_client.dart
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiClient {
  static final ApiClient _instance = ApiClient._internal();
  factory ApiClient() => _instance;

  ApiClient._internal();

  String? _accessToken;
  bool _isRefreshing = false;
  final List<Function> _pendingRequests = [];

  String? lastLoginError;

  /// БАЗОВЫЙ URL API 1С
  final String baseUrl = "https://intelligence.mova.beer/hs/api";

  // === загрузка токенов при запуске
  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    _accessToken = prefs.getString("access_token");
  }

  // === сохранить токены
  Future<void> _saveTokens(String access, String refresh) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString("access_token", access);
    await prefs.setString("refresh_token", refresh);
    _accessToken = access;
  }

  // === логин
  Future<bool> login(String login, String password) async {
    lastLoginError = null;
    try {
      final url = Uri.parse("$baseUrl/login");

      final r = await http
          .post(
        url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"login": login, "password": password}),
      )
          .timeout(const Duration(seconds: 15)); // чтобы точно не «висло»

      print('LOGIN STATUS: ${r.statusCode}');
      print('LOGIN BODY: ${r.body}');

      if (r.statusCode == 200) {
        final data = jsonDecode(r.body);
        await _saveTokens(data["access_token"], data["refresh_token"]);
        return true;
      } else {
        lastLoginError = 'HTTP ${r.statusCode}: ${r.body}';
        return false;
      }
    } on TimeoutException {
      lastLoginError = 'Таймаут запроса при логине';
      return false;
    } catch (e) {
      print('LOGIN EXCEPTION: $e');
      lastLoginError = 'Exception: $e';
      return false;
    }
  }

  // === refresh
  Future<bool> _refreshToken() async {
    final prefs = await SharedPreferences.getInstance();
    final refresh = prefs.getString("refresh_token");
    if (refresh == null) return false;

    try {
      final url = Uri.parse("$baseUrl/refresh");

      final r = await http
          .post(
        url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"refresh_token": refresh}),
      )
          .timeout(const Duration(seconds: 15));

      if (r.statusCode == 200) {
        final data = jsonDecode(r.body);
        await _saveTokens(data["access_token"], data["refresh_token"]);
        return true;
      }

      return false;
    } catch (e) {
      print('REFRESH EXCEPTION: $e');
      return false;
    }
  }

  Future<void> registerDeviceToken(String token) async {
    await post('/devices/register', body: {'token': token});
  }

  // === универсальный запрос с авто-refresh
  Future<http.Response> sendAuthorizedRequest(
      String method,
      String endpoint, {
        Map<String, String>? headers,
        Object? body,
      }) async {
    final url = Uri.parse("$baseUrl$endpoint");

    Future<http.Response> makeRequest() async {
      final hdr = <String, String>{
        "Content-Type": "application/json",
        if (_accessToken != null) "Authorization": "Bearer $_accessToken",
        if (headers != null) ...headers,
      };

      switch (method.toUpperCase()) {
        case "GET":
          return http.get(url, headers: hdr);
        case "POST":
          return http.post(url, headers: hdr, body: body);
        case "PUT":
          return http.put(url, headers: hdr, body: body);
        case "DELETE":
          return http.delete(url, headers: hdr);
        default:
          throw Exception("Unknown HTTP method: $method");
      }
    }

    var response = await makeRequest();

    if (response.statusCode != 401) {
      return response;
    }

    // если кто-то уже обновляет токен – встаём в очередь
    if (_isRefreshing) {
      final completer = Completer<http.Response>();
      _pendingRequests.add(() async {
        completer.complete(await makeRequest());
      });
      return completer.future;
    }

    _isRefreshing = true;
    final ok = await _refreshToken();
    _isRefreshing = false;

    if (!ok) {
      throw Exception("Refresh token expired – нужно логиниться заново");
    }

    for (final fn in _pendingRequests) {
      fn();
    }
    _pendingRequests.clear();

    return await makeRequest();
  }

  // === me
  Future<Map<String, dynamic>?> getMe() async {
    try {
      final r = await sendAuthorizedRequest("GET", "/me");
      if (r.statusCode == 200) {
        return jsonDecode(r.body) as Map<String, dynamic>;
      }
    } catch (e) {
    print('GetMe error: $e');
    }
    return null;
  }
}
