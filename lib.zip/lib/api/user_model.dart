// lib/api/user_model.dart

class UserModel {
  final String uid;
  final String name;
  final List<String> roles;

  UserModel({
    required this.uid,
    required this.name,
    required this.roles,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      uid: json["uid"] as String,
      name: json["name"] as String,
      roles: List<String>.from(json["roles"] ?? const []),
    );
  }

  bool get canApprovePayments =>
      roles.contains("Approver") ||
          roles.contains("Boss") ||
          roles.contains("Owner");
}
