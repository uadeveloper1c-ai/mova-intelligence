// lib/main.dart

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import 'api/api_client.dart';
import 'api/auth_provider.dart';
import 'core/router/app_router.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // 1. Инициализируем ApiClient (подтянет токены из SharedPreferences)
  final apiClient = ApiClient();
  await apiClient.init();

  // 2. Создаём провайдер авторизации
  final auth = AuthProvider();

  // 3. Пытаемся подтянуть поточного користувача через /me
  try {
    await auth.loadUser();
  } catch (e) {
    // на всякий случай просто игнорируем ошибку и считаем, что юзер не залогинен
    debugPrint('Помилка завантаження користувача: $e');
  }

  // 4. Создаём GoRouter, который будет следить за состоянием авторизации
  final router = AppRouter.createRouter(auth);

  // 5. Запускаем приложение с провайдерами
  runApp(
    MultiProvider(
      providers: [
        // AuthProvider для всього застосунку
        ChangeNotifierProvider<AuthProvider>.value(value: auth),

        // ApiClient, якщо захочеш діставати його через context.read<ApiClient>()
        Provider<ApiClient>.value(value: apiClient),
      ],
      child: MyApp(router: router),
    ),
  );
}

class MyApp extends StatelessWidget {
  final GoRouter router;
  const MyApp({super.key, required this.router});

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      routerConfig: router,
      debugShowCheckedModeBanner: false,
    );
  }
}
