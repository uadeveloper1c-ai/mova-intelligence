import 'package:hive/hive.dart';

class OrgAccess {
  final String code;
  final String name;

  OrgAccess({
    required this.code,
    required this.name,
  });

  factory OrgAccess.fromJson(Map<String, dynamic> json) {
    return OrgAccess(
      code: json['Код']?.toString() ?? '',
      name: json['Наименование']?.toString() ?? '',
    );
  }
}

class SessionData {
  final String token;
  final String fullName;
  final bool canApprovePayments;
  final List<OrgAccess> orgs;

  SessionData({
    required this.token,
    required this.fullName,
    required this.canApprovePayments,
    required this.orgs,
  });
}

class SessionStore {
  static const _boxName = 'session_box';

  static Future<Box> _openBox() async {
    if (Hive.isBoxOpen(_boxName)) {
      return Hive.box(_boxName);
    }
    return await Hive.openBox(_boxName);
  }

  static Future<void> saveSession(SessionData data) async {
    final box = await _openBox();
    await box.put('session', {
      'token': data.token,
      'fullName': data.fullName,
      'canApprovePayments': data.canApprovePayments,
      'orgs': data.orgs
          .map((o) => {
        'code': o.code,
        'name': o.name,
      })
          .toList(),
    });
  }

  static Future<SessionData?> loadSession() async {
    final box = await _openBox();
    final raw = box.get('session');
    if (raw == null) return null;

    final orgsRaw = (raw['orgs'] as List?) ?? [];
    final orgs = orgsRaw
        .map((m) => OrgAccess(
      code: m['code'] ?? '',
      name: m['name'] ?? '',
    ))
        .toList();

    return SessionData(
      token: raw['token'] ?? '',
      fullName: raw['fullName'] ?? '',
      canApprovePayments: raw['canApprovePayments'] ?? false,
      orgs: orgs,
    );
  }

  static Future<void> clear() async {
    final box = await _openBox();
    await box.delete('session');
  }
}
