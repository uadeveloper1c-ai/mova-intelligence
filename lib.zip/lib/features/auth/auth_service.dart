import 'package:dio/dio.dart';
import 'session_store.dart';

/// AuthService сейчас работает в мок-режиме:
/// - не ходит в реальный сервер
/// - генерирует фиктивный токен и права
/// Позже просто заменим тело login() на реальный POST в 1С.
class AuthService {
  final Dio _dio;
  final String baseUrl;

  AuthService(this._dio, {required this.baseUrl});

  Future<SessionData> login({
    required String username,
    required String password,
  }) async {
    try {
      final response = await _dio.post(
        '$baseUrl/post_login',
        data: {
          'login': username,
          'password': password,
        },
        options: Options(
          headers: {
            'Content-Type': 'application/json',
          },
        ),
      );

      if (response.statusCode == 200) {
        final data = response.data;

        final access = data['access_token'];
        final refresh = data['refresh_token'];
        final name = data['name'];
        final roles = List<String>.from(data['role'] ?? []);

        // если понадобится – сохраняем refresh в отдельное место,
        // но сейчас достаточно просто SessionStore
        final session = SessionData(
          token: access,
          fullName: name,
          canApprovePayments: roles.contains('Approver') ||
              roles.contains('Boss') ||
              roles.contains('Owner'),
          orgs: [], // пока пусто – добавим, когда сделаешь orgs в API
        );

        await SessionStore.saveSession(session);

        return session;
      }

      throw Exception("Login error: ${response.statusCode}");
    } catch (e) {
      throw Exception("Login failed: $e");
    }
  }
}