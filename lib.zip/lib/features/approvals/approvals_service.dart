import 'package:mova_intelligence_app/api/api_client.dart';
import 'domain/payment_request.dart';

class ApprovalsService {
  final ApiClient _apiClient;

  ApprovalsService(this._apiClient);

  // Мои заявки (история)
  Future<List<PaymentRequest>> getMyRequests() async {
    final json = await _apiClient.get('/approvals/my-requests');
    final list = (json as List)
        .cast<Map<String, dynamic>>()
        .map(PaymentRequest.fromJson)
        .toList();
    return list;
  }

  // Входящие на утверждение
  Future<List<PaymentRequest>> getIncomingRequests() async {
    final json = await _apiClient.get('/approvals/incoming');
    final list = (json as List)
        .cast<Map<String, dynamic>>()
        .map(PaymentRequest.fromJson)
        .toList();
    return list;
  }

  // Смена статуса (утвердить / отклонить / отмечать как оплачено)
  Future<PaymentRequest> changeStatus({
    required String id,
    required PaymentRequestStatus status,
    String? comment,
  }) async {
    final json = await _apiClient.post(
      '/approvals/requests/$id/status',
      body: {
        'Status': status.name, // или сделай маппу StatusTo1C
        if (comment != null && comment.isNotEmpty) 'Comment': comment,
      },
    );
    return PaymentRequest.fromJson(json as Map<String, dynamic>);
  }

  // ✨ Создание заявки из счёта (главное место для интеграции с invoices)
  Future<PaymentRequest> createFromInvoice({
    required String invoiceId,
    required double amount,
    required String purpose,
    required String supplierName,
  }) async {
    final json = await _apiClient.post(
      '/approvals/create-from-invoice',
      body: {
        'InvoiceId': invoiceId,
        'Amount': amount,
        'Purpose': purpose,
        'Supplier': supplierName,
      },
    );
    return PaymentRequest.fromJson(json as Map<String, dynamic>);
  }
}
