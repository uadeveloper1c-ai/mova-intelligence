import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../approvals_service.dart';
import '../domain/payment_request.dart';

class IncomingRequestsList extends StatelessWidget {
  const IncomingRequestsList({super.key});

  @override
  Widget build(BuildContext context) {
    final service = context.read<ApprovalsService>();

    return FutureBuilder<List<PaymentRequest>>(
      future: service.getIncomingRequests(),
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snap.hasError) {
          return Center(child: Text('Помилка: ${snap.error}'));
        }
        final items = snap.data ?? const [];

        if (items.isEmpty) {
          return const Center(child: Text('Немає заявок на погодження'));
        }

        return RefreshIndicator(
          onRefresh: () async {
            await service.getIncomingRequests();
          },
          child: ListView.separated(
            physics: const AlwaysScrollableScrollPhysics(),
            itemCount: items.length,
            separatorBuilder: (_, __) => const Divider(height: 0),
            itemBuilder: (context, i) {
              final r = items[i];
              return ListTile(
                title: Text('${r.number} · ${r.amount.toStringAsFixed(2)} ₴'),
                subtitle: Text(r.purpose),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      tooltip: 'Відхилити',
                      icon: const Icon(Icons.close),
                      onPressed: () => _onChangeStatus(
                        context,
                        r,
                        PaymentRequestStatus.rejected,
                      ),
                    ),
                    IconButton(
                      tooltip: 'Погодити',
                      icon: const Icon(Icons.check),
                      onPressed: () => _onChangeStatus(
                        context,
                        r,
                        PaymentRequestStatus.approved,
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        );
      },
    );
  }

  Future<void> _onChangeStatus(
      BuildContext context,
      PaymentRequest r,
      PaymentRequestStatus newStatus,
      ) async {
    final service = context.read<ApprovalsService>();

    try {
      await service.changeStatus(id: r.id, status: newStatus);
      if (!context.mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Статус заявки ${r.number} оновлено')),
      );
    } catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Помилка: $e')),
      );
    }
  }
}
