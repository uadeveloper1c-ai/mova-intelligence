import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../approvals_service.dart';
import '../domain/payment_request.dart';

class MyRequestsPage extends StatelessWidget {
  const MyRequestsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final service = context.read<ApprovalsService>();

    return Scaffold(
      appBar: AppBar(title: const Text('Мои заявки')),
      body: FutureBuilder<List<PaymentRequest>>(
        future: service.getMyRequests(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            if (snapshot.hasError) {
              return Center(child: Text('Ошибка: ${snapshot.error}'));
            }
            return const Center(child: CircularProgressIndicator());
          }

          final items = snapshot.data!;
          if (items.isEmpty) {
            return const Center(child: Text('Поки що заявок немає'));
          }

          return RefreshIndicator(
            onRefresh: () async {
              await service.getMyRequests();
            },
            child: ListView.separated(
              itemCount: items.length,
              separatorBuilder: (_, __) => const Divider(height: 0),
              itemBuilder: (context, i) {
                final r = items[i];
                return ListTile(
                  leading: _statusChip(r.status),
                  title: Text('${r.number} · ${r.amount.toStringAsFixed(2)} ₴'),
                  subtitle: Text(r.purpose),
                  trailing: Text(
                    '${r.createdAt.day}.${r.createdAt.month}.${r.createdAt.year}',
                    style: const TextStyle(fontSize: 12),
                  ),
                  onTap: () {
                    // тут можно открыть детальную страницу с таймлайном статусов
                  },
                );
              },
            ),
          );
        },
      ),
    );
  }

  Widget _statusChip(PaymentRequestStatus status) {
    final text = statusToHuman(status);
    Color? color;
    switch (status) {
      case PaymentRequestStatus.pending:
        color = Colors.orange;
        break;
      case PaymentRequestStatus.approved:
        color = Colors.green;
        break;
      case PaymentRequestStatus.rejected:
        color = Colors.red;
        break;
      case PaymentRequestStatus.paid:
        color = Colors.blue;
        break;
      case PaymentRequestStatus.draft:
        color = Colors.grey;
        break;
    }
    return CircleAvatar(
      radius: 18,
      backgroundColor: color.withOpacity(0.1),
      child: Text(
        text.substring(0, 1),
        style: TextStyle(color: color),
      ),
    );
  }
}
