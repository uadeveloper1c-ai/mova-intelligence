import 'package:flutter/material.dart';
import 'incoming_requests_list.dart';
import 'my_requests_list.dart';

class ApprovalsPage extends StatelessWidget {
  const ApprovalsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2, // 2 списка (входящие + мои)
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Заявки на оплату'),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'На погодженні'),
              Tab(text: 'Мої заявки'),
            ],
          ),
        ),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
              child: SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  icon: const Icon(Icons.add),
                  label: const Text('Нова заявка'),
                  onPressed: () {
                    // вариант A: открыть чистую форму NewRequestPage
                    // Navigator.of(context).push(...)

                    // вариант B (чтобы процесс не выбивался):
                    // перекинуть пользователя в раздел Invoices,
                    // чтобы он выбрал/создал рахунок, а там уже "Создать заявку".
                  },
                ),
              ),
            ),
            const Divider(height: 0),
            const Expanded(
              child: TabBarView(
                children: [
                  IncomingRequestsList(),
                  MyRequestsList(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
