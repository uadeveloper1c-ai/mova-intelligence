import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:mova_intelligence_app/features/auth/session_store.dart';
import 'package:mova_intelligence_app/features/approvals/approvals_service.dart';

class NewRequestPage extends StatefulWidget {
  const NewRequestPage({super.key});

  @override
  State<NewRequestPage> createState() => _NewRequestPageState();
}

class _NewRequestPageState extends State<NewRequestPage> {
  final _formKey = GlobalKey<FormState>();

  // поля формы
  final _amountCtrl = TextEditingController();
  final _purposeCtrl = TextEditingController();
  final _vendorNameCtrl = TextEditingController(); // Наименование поставщика
  final _vendorCodeCtrl = TextEditingController(); // ЕДРПОУ поставщика

  bool _urgent = false;
  String? _orgCode;
  List<OrgAccess> _orgs = [];
  DateTime? _desiredDate; // желательная дата платежа

  bool _sending = false;
  String? _error;

  late final ApprovalsService _service;

  @override
  void initState() {
    super.initState();
    _service = ApprovalsService(
      baseUrl: 'http://mail.mova.beer:20080',
      basicUser: 'Шапа Юрій',       // <- ВАШ сервисный логин 1С
      basicPass: 'r1n7bM6qRP',   // <- ВАШ сервисный пароль 1С
    );
    _loadSessionOrgs();
  }


  Future<void> _loadSessionOrgs() async {
    final session = await SessionStore.loadSession();
    setState(() {
      _orgs = session?.orgs ?? [];
      if (_orgs.isNotEmpty) {
        _orgCode = _orgs.first.code;
      }
    });
  }

  Future<void> _submit() async {
    final valid = _formKey.currentState?.validate() ?? false;
    if (!valid) return;

    if (_orgCode == null) {
      setState(() {
        _error = 'Выберите организацию';
      });
      return;
    }

    setState(() {
      _sending = true;
      _error = null;
    });

    try {
      final session = await SessionStore.loadSession();

      final payload = CreateRequestDto(
        orgCode: _orgCode!,
        amount: _amountCtrl.text.trim(),
        purpose: _purposeCtrl.text.trim(),
        urgent: _urgent,
        vendorName: _vendorNameCtrl.text.trim(),
        vendorCode: _vendorCodeCtrl.text.trim(),
        desiredDate: _desiredDate == null
            ? null
            : _desiredDate!.toIso8601String(),
      );

      final response = await _service.createPaymentRequest(
        dto: payload,
      );

// Можно захотеть показать номер заявки в снекбаре
      final humanNumber = response['request_number'] ?? '';
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Заявка $humanNumber отправлена ✅')),
      );

      context.go('/home');
    } catch (e) {
      setState(() {
        _error = 'Не удалось отправить заявку: $e';
      });
    } finally {
      if (mounted) {
        setState(() {
          _sending = false;
        });
      }
    }
  }

  @override
  void dispose() {
    _amountCtrl.dispose();
    _purposeCtrl.dispose();
    _vendorNameCtrl.dispose();
    _vendorCodeCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final orgItems = _orgs
        .map(
          (o) => DropdownMenuItem<String>(
        value: o.code,
        child: Text(o.name),
      ),
    )
        .toList();

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.go('/home'),
        ),
        title: const Text('Новая заявка'),
      ),
      body: AbsorbPointer(
        absorbing: _sending,
        child: Opacity(
          opacity: _sending ? 0.6 : 1,
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ===== КНОПКА "из файла / камеры" =====
                Card(
                  color: Colors.blueGrey.shade50,
                  child: ListTile(
                    leading: const Icon(Icons.document_scanner_outlined, size: 32),
                    title: const Text('Заполнить из файла / камеры'),
                    subtitle: const Text(
                      'Счёт, акт, накладная → сумма, назначение,\nпоставщик подтянутся автоматически',
                    ),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () {
                      context.push('/invoices/recognize');
                    },
                  ),
                ),

                const SizedBox(height: 24),

                // ===== ФОРМА =====
                Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Организация
                      const Text(
                        'Организация (кто платит)',
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(height: 6),
                      DropdownButtonFormField<String>(
                        value: _orgCode,
                        items: orgItems,
                        onChanged: (v) => setState(() => _orgCode = v),
                        validator: (v) =>
                        (v == null || v.isEmpty) ? 'Обязательно' : null,
                        decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          hintText: 'Выберите юрлицо',
                        ),
                      ),
                      const SizedBox(height: 16),

                      // Поставщик
                      const Text(
                        'Поставщик (название контрагента)',
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(height: 6),
                      TextFormField(
                        controller: _vendorNameCtrl,
                        decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          hintText: 'Например: ТОВ "Пиво Снаб"',
                        ),
                        validator: (v) =>
                        (v == null || v.trim().isEmpty)
                            ? 'Укажите поставщика'
                            : null,
                      ),
                      const SizedBox(height: 16),

                      // ЕДРПОУ поставщика
                      const Text(
                        'ЕДРПОУ поставщика',
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(height: 6),
                      TextFormField(
                        controller: _vendorCodeCtrl,
                        keyboardType:
                        const TextInputType.numberWithOptions(signed: false),
                        decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          hintText: 'Например: 12345678',
                        ),
                        validator: (v) =>
                        (v == null || v.trim().isEmpty)
                            ? 'Укажите ЕДРПОУ'
                            : null,
                      ),
                      const SizedBox(height: 16),

                      // Сумма
                      const Text(
                        'Сумма, ₴',
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(height: 6),
                      TextFormField(
                        controller: _amountCtrl,
                        keyboardType:
                        const TextInputType.numberWithOptions(decimal: true),
                        decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          hintText: 'Например: 12500.00',
                        ),
                        validator: (v) {
                          if (v == null || v.trim().isEmpty) {
                            return 'Введите сумму';
                          }
                          final num? parsed =
                          num.tryParse(v.replaceAll(',', '.'));
                          if (parsed == null || parsed <= 0) {
                            return 'Сумма некорректна';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 16),

                      // Назначение платежа
                      const Text(
                        'Назначение платежа',
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(height: 6),
                      TextFormField(
                        controller: _purposeCtrl,
                        maxLines: 3,
                        decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          hintText: 'За что платим? Кому? За какой период?',
                        ),
                        validator: (v) =>
                        (v == null || v.trim().isEmpty)
                            ? 'Заполните назначение'
                            : null,
                      ),
                      const SizedBox(height: 16),

                      // Желательная дата платежа
                      const Text(
                        'Желательная дата платежа',
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(height: 6),
                      InkWell(
                        onTap: () async {
                          final picked = await showDatePicker(
                            context: context,
                            initialDate: _desiredDate ?? DateTime.now(),
                            firstDate: DateTime.now(),
                            lastDate:
                            DateTime.now().add(const Duration(days: 365)),
                          );
                          if (picked != null) {
                            setState(() => _desiredDate = picked);
                          }
                        },
                        child: InputDecorator(
                          decoration: const InputDecoration(
                            border: OutlineInputBorder(),
                            hintText: 'Выберите дату платежа',
                          ),
                          child: Text(
                            _desiredDate == null
                                ? 'Не выбрана'
                                : '${_desiredDate!.day.toString().padLeft(2, '0')}.'
                                '${_desiredDate!.month.toString().padLeft(2, '0')}.'
                                '${_desiredDate!.year}',
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),

                      // Срочно
                      Row(
                        children: [
                          Checkbox(
                            value: _urgent,
                            onChanged: (v) =>
                                setState(() => _urgent = v ?? false),
                          ),
                          const Text('Срочно'),
                        ],
                      ),
                      const SizedBox(height: 24),

                      if (_error != null)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: Text(
                            _error!,
                            style: const TextStyle(
                              color: Colors.red,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),

                      SizedBox(
                        width: double.infinity,
                        child: FilledButton.icon(
                          onPressed: _sending ? null : _submit,
                          icon: const Icon(Icons.send),
                          label: const Text('Отправить заявку'),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// DTO
class CreateRequestDto {
  final String orgCode;
  final String vendorName;
  final String vendorCode;
  final String amount;
  final String purpose;
  final bool urgent;
  final String? desiredDate;

  CreateRequestDto({
    required this.orgCode,
    required this.vendorName,
    required this.vendorCode,
    required this.amount,
    required this.purpose,
    required this.urgent,
    this.desiredDate,
  });

  Map<String, dynamic> toJson() {
    return {
      'org_code': orgCode,
      'vendor_name': vendorName,
      'vendor_code': vendorCode,
      'amount': amount,
      'purpose': purpose,
      'urgent': urgent,
      if (desiredDate != null) 'desired_date': desiredDate,
    };
  }
}
