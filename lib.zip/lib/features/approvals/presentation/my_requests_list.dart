import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../approvals_service.dart';
import '../domain/payment_request.dart';

class MyRequestsList extends StatelessWidget {
  const MyRequestsList({super.key});

  @override
  Widget build(BuildContext context) {
    final service = context.read<ApprovalsService>();

    return FutureBuilder<List<PaymentRequest>>(
      future: service.getMyRequests(),
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snap.hasError) {
          return Center(child: Text('Помилка: ${snap.error}'));
        }
        final items = snap.data ?? const [];

        if (items.isEmpty) {
          return const Center(child: Text('Поки що заявок немає'));
        }

        return RefreshIndicator(
          onRefresh: () async {
            await service.getMyRequests();
          },
          child: ListView.separated(
            physics: const AlwaysScrollableScrollPhysics(),
            itemCount: items.length,
            separatorBuilder: (_, __) => const Divider(height: 0),
            itemBuilder: (context, i) {
              final r = items[i];
              return ListTile(
                leading: _statusDot(r.status),
                title: Text('${r.number} · ${r.amount.toStringAsFixed(2)} ₴'),
                subtitle: Text(r.purpose),
                trailing: Text(
                  statusToHuman(r.status),
                  style: const TextStyle(fontSize: 12),
                ),
              );
            },
          ),
        );
      },
    );
  }

  Widget _statusDot(PaymentRequestStatus status) {
    Color color;
    switch (status) {
      case PaymentRequestStatus.pending:
        color = Colors.orange;
        break;
      case PaymentRequestStatus.approved:
        color = Colors.green;
        break;
      case PaymentRequestStatus.rejected:
        color = Colors.red;
        break;
      case PaymentRequestStatus.paid:
        color = Colors.blue;
        break;
      case PaymentRequestStatus.draft:
        color = Colors.grey;
        break;
    }
    return CircleAvatar(radius: 5, backgroundColor: color);
  }
}
