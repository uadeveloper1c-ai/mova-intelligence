enum PaymentRequestStatus {
  draft,      // Черновик
  pending,    // На согласовании
  approved,   // Согласовано
  rejected,   // Отклонено
  paid,       // Оплачено
}

PaymentRequestStatus statusFrom1C(String value) {
  switch (value) {
    case 'Черновик': return PaymentRequestStatus.draft;
    case 'НаСогласовании': return PaymentRequestStatus.pending;
    case 'Согласовано': return PaymentRequestStatus.approved;
    case 'Отклонено': return PaymentRequestStatus.rejected;
    case 'Оплачено': return PaymentRequestStatus.paid;
    default: return PaymentRequestStatus.pending;
  }
}

String statusToHuman(PaymentRequestStatus s) {
  switch (s) {
    case PaymentRequestStatus.draft: return 'Черновик';
    case PaymentRequestStatus.pending: return 'На согласовании';
    case PaymentRequestStatus.approved: return 'Согласовано';
    case PaymentRequestStatus.rejected: return 'Отклонено';
    case PaymentRequestStatus.paid: return 'Оплачено';
  }
}

class PaymentRequest {
  final String id;          // внутренний ID 1С
  final String number;      // номер заявки
  final DateTime createdAt;
  final String requester;   // кто просит
  final String approver;    // кто утверждает
  final double amount;
  final String purpose;
  final PaymentRequestStatus status;

  PaymentRequest({
    required this.id,
    required this.number,
    required this.createdAt,
    required this.requester,
    required this.approver,
    required this.amount,
    required this.purpose,
    required this.status,
  });

  factory PaymentRequest.fromJson(Map<String, dynamic> j) {
    return PaymentRequest(
      id: j['Id'] as String,
      number: j['Number'] as String,
      createdAt: DateTime.parse(j['Date'] as String),
      requester: j['Requester'] as String,
      approver: j['Approver'] as String,
      amount: (j['Amount'] as num).toDouble(),
      purpose: j['Purpose'] as String,
      status: statusFrom1C(j['Status'] as String),
    );
  }
}
