import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    debugPrint('🏠 HomePage.build() demo version');

    return Scaffold(
      appBar: AppBar(
        title: const Text('MOVA — Дашборд'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ===== Блок "Сегодня" =====
            const Text(
              'Сегодня:',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),

            Wrap(
              spacing: 12,
              runSpacing: 12,
              children: [
                _statCard(
                  context,
                  icon: Icons.verified_outlined,
                  title: 'На согласование',
                  value: '3',
                  color: Colors.teal,
                  route: '/approvals',
                ),
                _statCard(
                  context,
                  icon: Icons.check_circle_outline,
                  title: 'Мои задачи',
                  value: '5',
                  color: Colors.indigo,
                  route: '/tasks',
                ),
                _statCard(
                  context,
                  icon: Icons.receipt_long_outlined,
                  title: 'Новые счета',
                  value: '2',
                  color: Colors.orange,
                  route: '/invoices',
                ),
                _statCard(
                  context,
                  icon: Icons.bar_chart_outlined,
                  title: 'Расходы (мес)',
                  value: '128 540 ₴',
                  color: Colors.redAccent,
                  route: '/reports',
                ),
              ],
            ),

            const SizedBox(height: 32),
            const Divider(),

            // ===== Блок "Быстрые действия" =====
            const Text(
              'Быстрые действия:',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),

            // "Сформировать заявку" — главный сценарий
            Card(
              child: ListTile(
                leading: const Icon(
                  Icons.playlist_add_circle_outlined,
                  size: 30,
                ),
                title: const Text('Сформировать заявку'),
                subtitle: const Text('Заявка на расход денежных средств'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () {
                  // ведём сразу на форму новой заявки
                  context.go('/approvals/new');
                },
              ),
            ),

            // История / последние документы
            Card(
              child: ListTile(
                leading: const Icon(Icons.history, size: 30),
                title: const Text('История заявок / счетов'),
                subtitle: const Text('Последние документы'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () {
                  context.go('/invoices');
                },
              ),
            ),

            // Переход в отчёты
            Card(
              child: ListTile(
                leading: const Icon(Icons.analytics_outlined, size: 30),
                title: const Text('Посмотреть отчёты'),
                subtitle: const Text('Основные метрики из 1С'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () {
                  context.go('/reports');
                },
              ),
            ),

            const SizedBox(height: 32),
            const Center(
              child: Text(
                'MOVA INTELLIGENCE (demo)',
                style: TextStyle(
                  fontSize: 13,
                  color: Colors.black54,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _statCard(
      BuildContext context, {
        required IconData icon,
        required String title,
        required String value,
        required Color color,
        required String route,
      }) {
    return GestureDetector(
      onTap: () => context.go(route),
      child: Container(
        width: MediaQuery.of(context).size.width / 2 - 22,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: color.withOpacity(0.3),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: color, size: 28),
            const SizedBox(height: 8),
            Text(
              title,
              style: TextStyle(
                color: color,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              value,
              style: TextStyle(
                color: color,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
