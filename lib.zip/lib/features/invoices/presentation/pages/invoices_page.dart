import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:go_router/go_router.dart';

import '../../../invoices/domain/invoice.dart';

class InvoicesPage extends StatefulWidget {
  const InvoicesPage({super.key});

  @override
  State<InvoicesPage> createState() => _InvoicesPageState();
}

class _InvoicesPageState extends State<InvoicesPage> {
  // поля новой заявки
  final numberCtrl = TextEditingController();
  final dateCtrl = TextEditingController();
  final supplierCtrl = TextEditingController();
  final amountCtrl = TextEditingController();
  final purposeCtrl = TextEditingController();

  @override
  void dispose() {
    numberCtrl.dispose();
    dateCtrl.dispose();
    supplierCtrl.dispose();
    amountCtrl.dispose();
    purposeCtrl.dispose();
    super.dispose();
  }

  Future<void> _openRecognizerAndFill() async {
    // ждём результат сканера
    final invoice = await context.push<Invoice>('/invoices/recognize');

    if (invoice != null) {
      setState(() {
        numberCtrl.text = invoice.number;
        dateCtrl.text = DateFormat('yyyy-MM-dd').format(invoice.date);
        supplierCtrl.text = invoice.supplier;
        amountCtrl.text = invoice.amount.toStringAsFixed(2);
        purposeCtrl.text = invoice.purpose;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Нова заява'),
      ),
      body: ListView(
        padding: EdgeInsets.fromLTRB(
          16,
          16,
          16,
          MediaQuery.of(context).viewInsets.bottom + 100,
        ),
        children: [
          // Номер счета
          TextFormField(
            controller: numberCtrl,
            decoration: const InputDecoration(
              labelText: 'Номер рахунка',
              prefixIcon: Icon(Icons.numbers_outlined),
            ),
          ),
          const SizedBox(height: 12),

          // Дата
          TextFormField(
            controller: dateCtrl,
            decoration: const InputDecoration(
              labelText: 'Дата (yyyy-MM-dd)',
              prefixIcon: Icon(Icons.event_outlined),
            ),
          ),
          const SizedBox(height: 12),

          // Поставщик
          TextFormField(
            controller: supplierCtrl,
            decoration: const InputDecoration(
              labelText: 'Постачальник',
              prefixIcon: Icon(Icons.store_mall_directory_outlined),
            ),
          ),
          const SizedBox(height: 12),

          // Сумма
          TextFormField(
            controller: amountCtrl,
            keyboardType:
            const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(
              labelText: 'Сума',
              prefixIcon: Icon(Icons.attach_money_outlined),
            ),
          ),
          const SizedBox(height: 12),

          // Назначение платежа
          TextFormField(
            controller: purposeCtrl,
            maxLines: 2,
            decoration: const InputDecoration(
              labelText: 'Призначення платежу',
              prefixIcon: Icon(Icons.text_fields_outlined),
            ),
          ),
          const SizedBox(height: 24),

          // Кнопка: распознать по фото и заполнить
          FilledButton.icon(
            icon: const Icon(Icons.document_scanner_outlined),
            label: const Text('Розпізнати по фото'),
            onPressed: _openRecognizerAndFill,
          ),

          const SizedBox(height: 24),

          // Кнопка: сохранить заявку (куда бы она у тебя потом не шла)
          FilledButton.icon(
            icon: const Icon(Icons.check_circle_outline),
            label: const Text('Зберегти заяву'),
            onPressed: () {
              // тут ты отправляешь эти данные дальше (в 1С, в Hive, куда надо)
              // numberCtrl.text
              // dateCtrl.text
              // supplierCtrl.text
              // amountCtrl.text
              // purposeCtrl.text
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Заява підготовлена')),
              );
            },
          ),

          const SizedBox(height: 12),

          // Можно сделать просмотр истории / переход на историю счетов
          OutlinedButton.icon(
            icon: const Icon(Icons.history_outlined),
            label: const Text('Історія розпізнавань'),
            onPressed: () {
              context.push('/invoices/history');
            },
          ),
        ],
      ),
      backgroundColor: theme.colorScheme.surface,
    );
  }
}
